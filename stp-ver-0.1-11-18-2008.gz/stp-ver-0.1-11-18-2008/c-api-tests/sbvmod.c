#include <stdio.h>
main() {
 signed x = -1 % -1;
 printf("output is %i \n",x);
}
